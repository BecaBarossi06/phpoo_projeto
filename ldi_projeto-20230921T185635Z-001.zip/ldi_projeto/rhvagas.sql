-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 06-Abr-2023 às 23:46
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `rhvagas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `candidato`
--

CREATE TABLE `candidato` (
  `Nome` varchar(200) NOT NULL,
  `CPF` bigint(20) NOT NULL,
  `Idade` int(11) NOT NULL,
  `sexo` varchar(200) NOT NULL,
  `etnia` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `candidato`
--

INSERT INTO `candidato` (`Nome`, `CPF`, `Idade`, `sexo`, `etnia`) VALUES
('Rafael', 35774224900, 34, 'M', 'Amarelo'),
('Tereza Xavier de Lima', 63767783123, 21, 'F', 'Preto'),
('Luan Machado Ferreira', 76417394273, 18, 'M', 'Branco'),
('Marisa Oliveira de Souza', 84295212825, 45, 'F', 'Indígena'),
('Rafaela Mendes Silveira', 95236412825, 25, 'F', 'Preto');

-- --------------------------------------------------------

--
-- Estrutura da tabela `empresa`
--

CREATE TABLE `empresa` (
  `codempresa` bigint(20) NOT NULL,
  `nomeempresa` varchar(200) NOT NULL,
  `estado` varchar(200) NOT NULL,
  `idadeempresa` int(11) NOT NULL,
  `unidadeempresa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `empresa`
--

INSERT INTO `empresa` (`codempresa`, `nomeempresa`, `estado`, `idadeempresa`, `unidadeempresa`) VALUES
(4534734600, 'Latam', 'RJ', 20, 30),
(5824636400, 'Gol', 'SC', 20, 60);

-- --------------------------------------------------------

--
-- Estrutura da tabela `perfilvaga`
--

CREATE TABLE `perfilvaga` (
  `codperfilvaga` int(11) NOT NULL,
  `especializacao` varchar(200) NOT NULL,
  `quantperfilvaga` int(11) NOT NULL,
  `cargahoraria` varchar(200) NOT NULL,
  `auxiliovida` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `perfilvaga`
--

INSERT INTO `perfilvaga` (`codperfilvaga`, `especializacao`, `quantperfilvaga`, `cargahoraria`, `auxiliovida`) VALUES
(234, 'secretaria', 7, 'seg a sab', 'nao'),
(345, 'programador', 9, 'ter a dom', 'sim');

-- --------------------------------------------------------

--
-- Estrutura da tabela `vagas`
--

CREATE TABLE `vagas` (
  `codempresa` bigint(20) NOT NULL,
  `codperfilvaga` int(11) NOT NULL,
  `codvaga` int(11) NOT NULL,
  `CPF` bigint(20) NOT NULL,
  `nomevaga` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `vagas`
--

INSERT INTO `vagas` (`codempresa`, `codperfilvaga`, `codvaga`, `CPF`, `nomevaga`) VALUES
(4534734600, 234, 1111, 84295212825, 'Secretariado'),
(4534734600, 234, 3333, 63767783123, 'Secretariado'),
(4534734600, 234, 4444, 76417394273, 'Secretariado'),
(5824636400, 345, 5555, 95236412825, 'TI'),
(5824636400, 345, 6666, 63767783123, 'TI');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `candidato`
--
ALTER TABLE `candidato`
  ADD PRIMARY KEY (`CPF`);

--
-- Índices para tabela `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`codempresa`);

--
-- Índices para tabela `perfilvaga`
--
ALTER TABLE `perfilvaga`
  ADD PRIMARY KEY (`codperfilvaga`);

--
-- Índices para tabela `vagas`
--
ALTER TABLE `vagas`
  ADD PRIMARY KEY (`codvaga`),
  ADD KEY `fk_CPF` (`CPF`),
  ADD KEY `fk_codempresa` (`codempresa`),
  ADD KEY `fk_codperfilvaga` (`codperfilvaga`);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `vagas`
--
ALTER TABLE `vagas`
  ADD CONSTRAINT `fk_CPF` FOREIGN KEY (`CPF`) REFERENCES `candidato` (`CPF`),
  ADD CONSTRAINT `fk_codempresa` FOREIGN KEY (`codempresa`) REFERENCES `empresa` (`codempresa`),
  ADD CONSTRAINT `fk_codperfilvaga` FOREIGN KEY (`codperfilvaga`) REFERENCES `perfilvaga` (`codperfilvaga`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

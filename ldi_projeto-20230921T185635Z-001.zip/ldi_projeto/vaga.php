<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>RH: Vaga e Seleção</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<link rel="shortcut icon" href="imagemldi/logoof.png">
</head>
<body>
	<div class="fundo" style="background-color: #010914; height: 100%;">
	        <!--menu!-->
		<div id="menu">
			<br>
		    	<a href="vaga.php">Vagas</a>
				<a href="perfilvaga.php">Perfil da vaga</a>
		    	<a href="candidato.php">Candidato</a>
		    	<a href="empresa.php">Empresa</a>
				<a href="index.php">Home</a>
		</div>
	    	<?php
			$c =mysqli_connect("localhost", "root", "", "rhvagas");

			if (mysqli_connect_errno() <> 0) {
				#conexão errada
				$msg = mysqli_connect_error();
				echo "<center>Erro na conexão com o banco!</center>" . $msg . "<br>";
			}
			else 
			{
				#Inserir dados no banco da tabela vagas
				$sql = "INSERT INTO vagas (codvaga, codperfilvaga, nomevaga, codempresa, CPF)
						VALUES (1111, 234, 'Secretariado', 4534734600, 84295212825),
							(2222, 234, 'Secretariado', 4534734600, 84295212825),
							(3333, 234, 'Secretariado', 4534734600, 35774224900),
							(4444, 234, 'Secretariado', 4534734600, 76417394273),
							(5555, 345, 'TI', 5824636400, 95236412825),
							(6666, 345, 'TI', 5824636400, 63767783123);";
					$result = mysqli_query($c, $sql);
					
					if (!$result) {
						#erro na inclusão
						$msg = mysqli_error($c);
						echo "<center>Erro na inclusão do Registros!</center>" . $msg . "<br>";
					}
					else
					{
						#inclusão ok
						echo "<center>Registro incluidos!</center>" . "<br>";
					}
				
				$sql = "UPDATE vagas SET CPF=63767783123 WHERE codvaga=3333";
					$altera = mysqli_query($c,$sql);
					if (!$altera) {
								$msg = mysqli_error($c);
								echo "<center>Erro no update</center>" . $msg . "<br>";
					}
					else
					{
		                echo "<center>Update ok</center>", "<br>";
					}
					$sql = "DELETE FROM vagas WHERE codvaga = 2222;";
					$deletar = mysqli_query($c, $sql);
					if (!$deletar) {
						echo "<br>" . "<center>Erro ao deletar registro!</center>";
					}
					else
					{
						echo "<br>" . "<center>Registro deletado com sucesso</center>";
					}
				
				$sql = "SELECT * FROM vagas";
				$consulta = mysqli_query($c, $sql);
				for ($i = 0; $i < mysqli_num_rows($consulta); $i++) {
				  echo "<br>"."<center>Resultado do Select full de vagas:"."<br>";
				  $linha = mysqli_fetch_assoc($consulta);
				  echo "<br>". $linha['codvaga'] . "<br>". $linha['codperfilvaga'] . "<br>" .  $linha['nomevaga'] . "<br>".  $linha['codempresa'] . "<br>".  $linha['CPF'] . "<br>";
				}
		
				$sql = "SELECT nomevaga FROM vagas WHERE codvaga = 2222";
				$consulta = mysqli_query($c, $sql);
				if (mysqli_num_rows($consulta) <> 0) {
				  # code...
				  echo "<br>" . "<center>Resultado do Select com chave codvaga de vagas:</center>"."<br>";
				  $linha = mysqli_fetch_assoc($consulta);
				  echo "<br>". $linha['nomevaga'] . "<br>";
				  }
		
				  $sql = "SELECT codperfilvaga, nomevaga FROM vagas WHERE CPF = 35774224900
				   and codvaga = 3333 ";
				  $consulta = mysqli_query($c, $sql);
				  if (mysqli_num_rows($consulta) <> 0) {
					# code...
					echo "<br>" . "<center>Resultado do Select sem chave de vagas:</center>"."<br>";
					$linha = mysqli_fetch_assoc($consulta);
					echo "<br>". $linha['Nome'] . "<br>" . $linha['Idade'] . "<br>" ;
					}
			}
			?>
			<div class="imagem">
        <img src="imagemldi/imag.png">
    </div>
</div>




</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>RH: Vaga e Seleção</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
    <link rel="shortcut icon" href="imagemldi/logoof.png">
</head>
<body>
	<div class="fundo" style="background-color: #010914; height: 100%;">
        <!--menu!-->
        <div id="menu">
            <br>
                <a href="vaga.php">Vagas</a>
				<a href="perfilvaga.php">Perfil da vaga</a>
		    	<a href="candidato.php">Candidato</a>
		    	<a href="empresa.php">Empresa</a>
				<a href="index.php">Home</a>
        </div>

    <?php
        $c =mysqli_connect("localhost", "root", "", "rhvagas");
        if (mysqli_connect_errno() <> 0) {
            #conexão errada
            $msg = mysqli_connect_error();
            echo "<center>Erro na conexão com o banco!</center>" . $msg . "<br>";
        }
        else 
        {
            #Inserir dados no banco da tabela candidatos
            $sql = "INSERT INTO candidato (Nome, CPF, Idade, sexo, etnia)
            VALUES ('Paola Machado Diniz', 24663232698, 37, 'F', 'Branco'),
            ('Rafik Almeida da Silva',35774224900, 34, 'M', 'Amarelo'),
            ('Rafaela Mendes Silveira', 95236412825, 25, 'F', 'Preto'),
            ('Marisa Oliveira de Souza', 84295212825, 45, 'F', 'Indígena'),
            ('Luan Machado Ferreira', 76417394273, 18, 'M', 'Branco'),
            ('Tereza Xavier de Lima', 63767783123, 21, 'F', 'Preto');";
            $result = mysqli_query($c, $sql);

            if (!$result) {
                #erro na inclusão
                $msg = mysqli_error($c);
                echo "<center>Erro na inclusão!</center>" . $msg. "<br>";
            }
            else
            {
                #inclusão ok
                echo "<center>Registro incluidos com sucesso!</center>" . "<br>";
            }
        
        $sql="UPDATE candidato SET Nome = 'Rafael' WHERE CPF =35774224900";
        $altera = mysqli_query($c,$sql);
        if (!$altera) {
            $msg = mysqli_error($c);
            echo "<center>Erro no update</center>". $msg . "<br>";
        }
        else
        {
            echo "<center>Update ok!</center>". "<br>";
        }
        $sql = "DELETE FROM candidato WHERE CPF = 24663232698;";
            $deletar = mysqli_query($c, $sql);
            if (!$deletar) {
                echo "<br>" . "<center>Erro ao deletar registro!</center>";
            }
            else
            {
                echo "<br>" . "<center>Registro deletado com sucesso</center>";
            }
        
        $sql = "SELECT * FROM candidato";
        $consulta = mysqli_query($c, $sql);
        for ($i = 0; $i < mysqli_num_rows($consulta); $i++) {
          echo "<br>"."<center>Resultado do Select full de candidato:"."<br>";
          $linha = mysqli_fetch_assoc($consulta);
          echo "<br>". $linha['Nome'] . "<br>". $linha['CPF'] . "<br>" .  $linha['Idade'] . "<br>" .  $linha['sexo'] . "<br>" .  $linha['etnia'] . "<br>";
        }

        $sql = "SELECT Nome FROM candidato WHERE CPF = 35774224900";
        $consulta = mysqli_query($c, $sql);
        if (mysqli_num_rows($consulta) <> 0) {
          # code...
          echo "<br>" . "<center>Resultado do Select com chave CPF de candidato:</center>"."<br>";
          $linha = mysqli_fetch_assoc($consulta);
          echo "<br>". $linha['Nome'] . "<br>";
          }

          $sql = "SELECT Nome, Idade FROM candidato WHERE sexo = 'F'
           and etnia= 'Preto'";
          $consulta = mysqli_query($c, $sql);
          if (mysqli_num_rows($consulta) <> 0) {
            # code...
            echo "<br>" . "<center>Resultado do Select sem chave de candidato:</center>"."<br>";
            $linha = mysqli_fetch_assoc($consulta);
            echo "<br>". $linha['Nome'] . "<br>" . $linha['Idade'] . "<br>" ;
            }
        }

    ?>
    <div class="imagem">
        <img src="imagemldi/imag.png">
    </div>
</div>



</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>RH: Vaga e Seleção</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<link rel="shortcut icon" href="imagemldi/logoof.png">
</head>
<body>
	<div id="fundoimagem" style="background-image: url(imagemldi/foto.jpg);">
    <div id="menu">
    	<br>
    			<a href="vaga.php">Vagas</a>
				<a href="perfilvaga.php">Perfil da vaga</a>
		    	<a href="candidato.php">Candidato</a>
		    	<a href="empresa.php">Empresa</a>
				<a href="index.php">Home</a>	

	</div>
		<!-- nome da empresa de rh!-->
		<div id="nome">
			<h3>RH</h3>
			<h1>Vagas e Seleções</h1>	
		</div>
		<!--texto inicial!-->
		<div id="texto-index">
			<h3>Empresa de RH</h3>
			<p>Incluindo você no mercado de trabalho!</p>
		</div>
	</div>
	</body>
</html>
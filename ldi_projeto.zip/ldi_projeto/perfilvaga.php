<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>RH: Vaga e Seleção</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
    <link rel="shortcut icon" href="imagemldi/logoof.png">
</head>
<body>
    <div class="fundo" style="background-color: #010914; height: 100%;">
    	<!--menu!-->
        <div id="menu">
            <br>
                <a href="vaga.php">Vagas</a>
				<a href="perfilvaga.php">Perfil da vaga</a>
		    	<a href="candidato.php">Candidato</a>
		    	<a href="empresa.php">Empresa</a>
				<a href="index.php">Home</a>
        </div>
   

    <?php
        $c =mysqli_connect("localhost", "root", "", "rhvagas");

        if (mysqli_connect_errno() <> 0) {
            #conexão errada
            $msg = mysqli_connect_error();
            echo "<center>Erro na conexão com o banco!</center>" . $msg . "<br>";
        }
        else 
        {
            $sql = "INSERT INTO perfilvaga (codperfilvaga, especializacao, quantperfilvaga, cargahoraria, auxiliovida)
            VALUES (123, 'jardineiro', 5, 'seg a sex', 'sim'),
            (234, 'secretaria', 7, 'seg a sab', 'nao'),
            (345, 'programador', 9, 'ter a dom', 'sim');";
            $result = mysqli_query($c, $sql);

            if (!$result) {
                #erro na inclusão
                $msg = mysqli_error($c);
                echo "<center>Erro na inclusão!</center>" . $msg. "<br>";
            }
            else
            {
                #inclusão ok
                echo "<center>Registro incluidos com sucesso!</center>" . "<br>";
            }

        
        $sql = "UPDATE perfilvaga SET especializacao='contador' WHERE codperfilvaga=123";
        $altera = mysqli_query($c,$sql);
        if (!$altera) {
                $msg = mysqli_error($c);
                echo "<center>Erro no update</center>" . $msg . "<br>";
        }
        else
        {
                echo "<center>Update ok</center>", "<br>";
        }
        $sql = "DELETE FROM perfilvaga WHERE codperfilvaga = 123;";
            $deletar = mysqli_query($c, $sql);
        if (!$deletar) {
            echo "<br>" . "<center>Erro ao deletar registro!</center>";
        }
        else
        {
            echo "<br>" . "<center>Registro deletado com sucesso</center>";
        }
    
    $sql = "SELECT * FROM perfilvaga";
				$consulta = mysqli_query($c, $sql);
				for ($i = 0; $i < mysqli_num_rows($consulta); $i++) {
				  echo "<br>"."<center>Resultado do Select full de perfilvaga:"."<br>";
				  $linha = mysqli_fetch_assoc($consulta);
				  echo "<br>". $linha['codperfilvaga'] . "<br>". $linha['especializacao'] . "<br>" . $linha['quantperfilvaga'] . "<br>" . $linha['cargahoraria'] . "<br>" . $linha['auxiliovida'] . "<br>";
				}
		
				$sql = "SELECT especializacao FROM perfilvaga WHERE codperfilvaga = 345";
				$consulta = mysqli_query($c, $sql);
				if (mysqli_num_rows($consulta) <> 0) {
				  # code...
				  echo "<br>" . "<center>Resultado do Select com chave codperfilvaga de perfilvaga:</center>" . "<br>";
				  $linha = mysqli_fetch_assoc($consulta);
				  echo "<br>". $linha['especializacao'] . "<br>";
				  }
		
				  $sql = "SELECT especializacao, cargahoraria FROM perfilvaga WHERE quantperfilvaga = 5
				   and auxiliovida = 'sim'";
				  $consulta = mysqli_query($c, $sql);
				  if (mysqli_num_rows($consulta) <> 0) {
					# code...
					echo "<br>" . "<center>Resultado do Select sem chave de perfilvaga:</center>"."<br>";
					$linha = mysqli_fetch_assoc($consulta);
					echo "<br>". $linha['especializacao'] . "<br>" . $linha['cargahoraria'] . "<br>" ;
					}
                }
    ?>
    <div class="imagem">
        <img src="imagemldi/imag.png">
    </div>
</div>


</body>
</html>
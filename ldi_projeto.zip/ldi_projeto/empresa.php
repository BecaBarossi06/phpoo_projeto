<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>RH: Vaga e Seleção</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
    <link rel="shortcut icon" href="imagemldi/logoof.png">
</head>
<body>
<div class="fundo" style="background-color: #010914; height: 100%; right: 100%;">

            <!--menu!-->
        <div id="menu">
           <br>
                <a href="vaga.php">Vagas</a>
				<a href="perfilvaga.php">Perfil da vaga</a>
		    	<a href="candidato.php">Candidato</a>
		    	<a href="empresa.php">Empresa</a>
				<a href="index.php">Home</a>
        </div>
    <?php
        $c =mysqli_connect("localhost", "root", "", "rhvagas");

        if (mysqli_connect_errno() <> 0) {
            #conexão errada
            $msg = mysqli_connect_error();
            echo "<center>Erro na conexão com o banco!</center>" . $msg . "<br>";
        }
        else 
        {
               #Inserir dados no banco da tabela empresa, codempresa é o cnpj dela
                $sql = "INSERT INTO empresa (codempresa, nomeempresa, estado, idadeempresa, unidadeempresa)
                        VALUES (5798224600, 'Itaú', 'SP', 20, 50),
                        (4534734600, 'Latam', 'RJ', 20, 30),
                        (5824636400, 'Gol', 'SC', 20, 60);";
                $result = mysqli_query($c, $sql);
            
            if (!$result) {
                #erro na inclusão
                $msg = mysqli_error($c);
                echo "<center>Erro na inclusão do Registros!</center>" . $msg. "<br>";
            }
            else
            {
                #inclusão ok
                echo "<center>Registro incluidos!</center>" . "<br>";
            }
        
            $sql="UPDATE empresa SET nomeempresa = 'Chilena' WHERE  codempresa =4335735600";
            $altera = mysqli_query($c,$sql);
            if (!$altera) {
                $msg = mysqli_error($c);
                echo "<center>Erro no update</center>". $msg . "<br>";
            }
            else
            {
                echo "<center>Update ok!</center>". "<br>";
            }

           $sql = "DELETE FROM empresa WHERE codempresa = 5798224600;";
           $deletar = mysqli_query($c, $sql);
            if (!$deletar) {
                echo "<br>" . "<center>Erro ao deletar registro!</center>";
            }
            else
            {
                echo "<br>" . "<center>Registro deletado com sucesso</center>";
            }
        

        $sql = "SELECT * FROM empresa";
        $consulta = mysqli_query($c, $sql);
        for ($i = 0; $i < mysqli_num_rows($consulta); $i++) {
          echo "<br>"."<center>Resultado do Select full de empresa:"."<br>";
          $linha = mysqli_fetch_assoc($consulta);
          echo "<br>". $linha['codempresa'] . "<br>". $linha['nomeempresa'] . "<br>" . $linha['estado'] . "<br>" . $linha['idadeempresa'] . "<br>" . $linha['unidadeempresa'] . "<br>";
        }

        $sql = "SELECT nomeempresa FROM empresa WHERE codempresa = 4534734600";
        $consulta = mysqli_query($c, $sql);
        if (mysqli_num_rows($consulta) <> 0) {
          # code...
          echo "<br>" . "<center>Resultado do Select com chave codempresa de empresa:</center>"."<br>";
          $linha = mysqli_fetch_assoc($consulta);
          echo "<br>". $linha['nomeempresa'] . "<br>";
          }

          $sql = "SELECT nomeempresa, estado FROM empresa WHERE idadeempresa = 20
          and unidadeempresa = 50";
         $consulta = mysqli_query($c, $sql);
         if (mysqli_num_rows($consulta) <> 0) {
           # code...
           echo "<br>" . "<center>Resultado do Select sem chave de empresa:</center>"."<br>";
           $linha = mysqli_fetch_assoc($consulta);
           echo "<br>". $linha['nomeempresa'] . "<br>" . $linha['estado'] . "<br>" ;
           }

        }
    ?> 
        <div class="imagem">
        <img src="imagemldi/imag.png">
    </div>
</div>
  




</body>
</html>
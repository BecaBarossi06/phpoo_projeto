<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Donuts LuPoRe</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<link rel="shortcut icon" href="imagemldi/logoof.png">
</head>
<body>
    	<div id="menu">
    	<br>	
				<a href="index.php">Home</a>
				<a href="sobrenos.php">Sobre nós</a>
    			<a href="cadastrar-usuario.php">Cadastre-se</a>
				<a href="login.php">Login</a>
		</div>

		

		<div id="nome-index">
			<h3>Donuts</h3>
			<h1>LuPoRe</h1>
			<p> A Donuteria Central é mais do que uma loja de donuts; é um destino para os amantes de doces. Venha nos visitar hoje mesmo e experimente a mágica dos donuts frescos feitos com amor.</p>
			<br> Numa pequena cidade, onde os aromas e sabores das ruas eram tão familiares quanto os rostos que passavam, três amigas compartilhavam uma paixão comum: donuts. Poliana, Rebeca e Luana eram inseparáveis desde a infância, e seu amor por essas delícias redondas e recheadas os uniu ainda mais ao longo dos anos.</s>	
			<br> Finalmente, decidiram transformar seu sonho em realidade. Com determinação e paixão, Poliana, a visionária do grupo, pesquisou localizações, Rebeca, a mestra da cozinha, começou a aperfeiçoar suas receitas e Luana, a especialista em marketing, cuidou da marca e da divulgação. <br><br>
			Finalmente, decidiram transformar seu sonho em realidade. Com determinação e paixão, Poliana, a visionária do grupo, pesquisou localizações, Rebeca, a mestra da cozinha, começou a aperfeiçoar suas receitas e Luana, a especialista em marketing, cuidou da marca e da divulgação.<br> A loja de donuts de Poliana, Rebeca e Luana não era apenas um negócio; era um testemunho de sua amizade e de sua dedicação à arte de fazer donuts. Elas compartilharam risadas, desafios e sucessos enquanto transformavam seu sonho em uma loja de donuts que todos na cidade amavam.</s>
		</div>

  




</body>
</html>
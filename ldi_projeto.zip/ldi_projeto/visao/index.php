<!DOCTYPE html>
<?php
session_start(); 

include '..\controladora\conexao.php';
include '..\modelo\Produto.php';
include '..\Repositorio\ProdutoRepositorio.php';

$produtosRepositorio = new ProdutoRepositorio($conn);
$donuts = $produtosRepositorio->listarDonuts();
?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Donuts LuPoRe</title>
	
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
	<link rel="shortcut icon" href="../imagemldi/logocima.jpg">
</head>
<body>
    	<div id="menu">
    	<br>	
				<a href="index.php">Home</a>
				<a href="sobrenos.php">Sobre nós</a>
    
                <?php
                if (isset($_SESSION["nomeusuario"])){ ?>
                    <a href="admin.php">Admin</a>
                    <a> <?php echo $_SESSION["nomeusuario"];?> </a>
               <?php } else { ?>
                    <a href="cadastrar-usuario.php">Cadastre-se</a>
                    <a href="login.php">Login</a>
               <?php } ?>
				<div class="user-photo">
                <img src="..\imagemldi\logocima.jpg" alt="Foto do Usuário">
              
            </div>
		</div>
        





	
		<!--imagem lateral!-->
		<div id="imagem-lateral">
		<img src="../imagemldi/donutshome.png">
		</div>

		<div id="nome-index">
			<h3>Donuts</h3>
			<h1>LuPoRe</h1>
			<p>Bem-vindo ao lugar onde sonhos se transformam em realidade, onde cada mordida é uma explosão de sabor e onde a felicidade vem em forma de rosquinhas.</p>	
		</div>

        <div class="container">
    <?php foreach ($donuts as $donut): ?>
        <div class="container-produto">
            <div class="container-foto">
                <img src="<?= $donut->getImagemDiretorio() ?>">
            </div>
            <p><?= $donut->getNome() ?></p>
            <p><?= "R$ " . number_format($donut->getPreco(), 2) ?></p>
        </div>
    <?php endforeach; ?>
</div>

      
    </div>
	
	</body>
</html>